# Contents of coolmath/coolmath/__init__.py:

from .math_operations import add, subtract, multiply, divide
