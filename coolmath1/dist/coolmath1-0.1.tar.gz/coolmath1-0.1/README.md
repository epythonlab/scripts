# coolmath

A simple Python library for basic mathematical operations.

## Installation

You can install this library using pip:

```bash
pip install coolmath

python setup.py sdist bdist_wheel
you can upload to the packing library index PyPI

to upload it
you need to install
pip install twine

pip install coolmath

from coolmath 