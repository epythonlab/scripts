# coolmath

A simple Python library for basic mathematical operations.

## Installation

You can install this library using pip:

```bash
pip install coolmath
```
# Usage

```bash
from coolmath import add, subtract, multiply, divide

result_add = add(5, 3)
result_subtract = subtract(10, 4)
result_multiply = multiply(6, 7)
result_divide = divide(8, 2)

print(f"Addition: {result_add}")
print(f"Subtraction: {result_subtract}")
print(f"Multiplication: {result_multiply}")
print(f"Division: {result_divide}")

